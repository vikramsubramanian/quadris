#include <gtkmm/window.h>	    // Gtk::Window

class MyWindow : public Gtk::Window {
public:
	MyWindow();
};
