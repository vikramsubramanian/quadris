#include "window.h"

MyWindow::MyWindow() {
	set_title( "Example 2" );      // Sets the window title.
	set_default_size( 500, 200 );  // Set default size, width and height, in pixels.
}
