Shows how to build a window derived from a Gtk::Window.

If this does not compile for you, perform the following commands in the terminal (ignore '-'):
- bash
- source /u/cs_build/gtkmm/setup
- exit
