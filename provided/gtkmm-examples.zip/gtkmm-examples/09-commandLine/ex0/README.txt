Example comes from:

https://git.gnome.org//browse/glibmm/tree/examples/options/main.cc

April 11, 2018
