Example taken from:

https://github.com/GNOME/gtkmm-documentation/tree/gtkmm-3-22/examples/book/application/simple

April 13, 2018
