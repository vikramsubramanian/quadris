https://developer.gnome.org/gtkmm-tutorial/stable/chapter-drawingarea.html.en

Make sure you read through this section on the Cairo drawing model if you want to play with the drawing area.

There's a Cairo tutorial at https://www.cairographics.org/tutorial/.

ex8 is an example of a drawing area embedded in a ViewPort, then embedded in a ScrolledWindow

ex9 adds a text entry widget combined with a drawing area.
