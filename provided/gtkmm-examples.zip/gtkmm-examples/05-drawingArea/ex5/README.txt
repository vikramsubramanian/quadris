Drawing text example
