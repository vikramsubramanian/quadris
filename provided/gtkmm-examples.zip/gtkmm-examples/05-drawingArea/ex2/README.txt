Drawing thin lines example
