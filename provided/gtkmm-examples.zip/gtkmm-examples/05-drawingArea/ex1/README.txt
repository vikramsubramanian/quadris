Drawing lines example
