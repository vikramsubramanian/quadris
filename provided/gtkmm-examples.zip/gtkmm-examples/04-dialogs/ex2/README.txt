File/folder chooser dialog example
