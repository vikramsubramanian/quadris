https://www.pexels.com/photo/animal-pet-fur-head-33537/
https://www.pexels.com/photo/orange-white-cat-115011/
https://www.pexels.com/photo/animal-animal-photography-animal-portrait-big-208840/
