ex1 shows two types of Gtk::MessageDialogs, one for information, and one for questions.
