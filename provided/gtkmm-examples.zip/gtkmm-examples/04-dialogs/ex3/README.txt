Colour chooser dialog example
