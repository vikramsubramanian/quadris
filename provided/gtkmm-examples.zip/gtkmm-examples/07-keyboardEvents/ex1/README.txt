"In this example there are three keyboard shortcuts: Alt+1 selects the first radio 
button, Alt+2 selects the second one, and the Esc key hides (closes) the window. 
The default event signal handler is overridden, as described in the Overriding 
default signal handlers section in the appendix."
