These examples were created using an older version of gtkmm.

Examples 01, 02, 07, and MVC are still functional in gtkmm 3.0 (current version
  of gtkmm as of S18).

Examples 03-06 have not been posted since they use deprecated functions and
  therefore are no longer functional in gtkmm 3.0.

